Alex Egg 
809236396
eggie5@gmail.com

The encoder is in 'encoder.m' and the decoder is in 'decoder.m' to run the program execute 'runner.m' by typing 'runner' in the command line in the work directory w/ the project files.
