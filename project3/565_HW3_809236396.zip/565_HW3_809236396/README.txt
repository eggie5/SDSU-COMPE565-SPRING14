Alex Egg
809236396
eggie5@gmail.com

Project 3

To run the project open this directory in matlab as your work space. You must have these files:

costFuncMAD.m
imgPSNR.m
minCost.m
motionComp.m
motionEstES.m
motionEstTSS.m
proj3.m
walk_qcif.avi

Which should have come w/ the zip file.

The main file is proj3.m. To run the program, just run:

proj3

in matlab. It will print out the figure and some states. This information is also included in the report.