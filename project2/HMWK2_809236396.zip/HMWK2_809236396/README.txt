Compe 565 - Homework 2

AlexEgg
809236396
eggie5@gmail.com

M-File name: jpeg_encode.m

Supporting files: zigzag.m

Usage:

Make sure jpeg_encode.m & zigzag.m & SunView.jpg are in your matlab working directory. The main file is jpeg_encode.m. It is just a script, that assumes that SunView.jpg is in the working directory and runs the encoding/decoding routine and displays the figures. 

All figures are also included in the report

To run the script:

jpeg_encode
